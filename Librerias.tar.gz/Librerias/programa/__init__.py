from ClasesLibrerias import Transformar as trans
from ClasesLibrerias import Multiusos as multi
from ClasesLibrerias import Encontrar as encontrar
from ClasesLibrerias import Reconocimiento as reconocer

import numpy as np
import argparse
import cv2


def Main(img):
      image = multi.cargar(img)

      cv2.imshow("origen",image)

      focus,coordenadas,cantidad = encontrar.Encontrar(image)
      imagen2 = trans.four_point_transform(focus, coordenadas[0])
      imagen2 = cv2.resize(imagen2.copy(), (800,1024),interpolation = cv2.INTER_AREA)
      #multi.guardar(imagen2,"imagen2.jpg")
      imagen2 = multi.opening(imagen2)
      cv2.imshow("imagen2", imagen2)
      a = np.array( (149,373,149,789,678,368,677,790))
      ad= trans.order_points(a)
      b = np.array((557,149,557,322,743,143,740,317))
      bd = trans.order_points(b)
      respuestas = trans.four_point_transform(imagen2,a)
      multi.guardar(respuestas,"respuestas.jpg")
      cv2.imshow("Respuestas",respuestas)

      qr = trans.four_point_transform(imagen2,b)
      qr = cv2.cvtColor(qr,cv2.COLOR_BGR2GRAY)
      qr = cv2.threshold(qr,0,255,
            cv2.THRESH_BINARY |  cv2.THRESH_OTSU)[1]
      qr = multi.opening(qr)

      reconocer.LeerQR(qr,"primero")
      reconocer.prueba(10, 3, respuestas)
      cv2.waitKey(0)
