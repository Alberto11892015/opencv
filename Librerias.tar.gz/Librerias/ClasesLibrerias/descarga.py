'''
Created on 19/10/2016

@author: agaa8
'''
from PIL import Image
from urllib import urlopen
from StringIO import StringIO

URL = 'http://pruebaswebphp.hol.es/uploads/1476898682705.jpg'

data = urlopen(URL).read()  # descarga y almacena la imagen en una cadena
file = StringIO(data)  # trata la cadena como un fichero
img = Image.open(file)  # lee el fichero y devuelve la imagen

#img_rot = img.rotate(90)  # rotar la imagen 90 grados
img.save('E:/imagenlocal2.jpg')  # y salvar la imagen en local
print "imagen salvada"
