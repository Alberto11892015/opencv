'''
Created on 10/10/2016

@author: agaa8
'''
from ClasesLibrerias import Multiusos as multi
import numpy as np
import cv2



def Encontrar(img):

    
    gray = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray,11,17,17)
    #blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edged =cv2.Canny(gray,75,200)
    #kernel = np.ones((5,5),np.uint8)
    #edged = cv2.dilate(edged,kernel,iterations = 8)

    imagesd = cv2.resize(edged.copy(), (800,1024),interpolation = cv2.INTER_AREA)

    #cv2.imshow("Edge",imagesd)

    (x,cnts,_) = cv2.findContours(edged.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)

    cnts = sorted(cnts,key = cv2.contourArea,reverse = True)[:10]
    screencnt = None
    agregar = 0
    numero = 0
    area=[]
    lista = []
    for c in cnts:
        peri = cv2.arcLength(c,True)
        approx = cv2.approxPolyDP(c,0.15*peri,True)
        
        if len(approx)==4:
            areas = cv2.contourArea(c)
           
            areaatratar = areas +50
            rect = np.zeros((4,2),dtype="Float32")
            screencnt = approx
           
            if(numero == 0):

                lista.append(rect)
                area.append(areas)
                agregar = agregar +1
                #cv2.drawContours(img, [screencnt], -1, (0, 255, 0), 1)
                
            if(numero != 0):
                if(agregar <5):
                    if int (area[agregar -1])>areaatratar:

                        lista.append(rect)  
                        
                        area.append(areas)  
                        agregar = agregar +1
                 #       cv2.drawContours(img, [screencnt], -1, (0, 255, 0), 1)
                        
            
            pts = screencnt.reshape(4, 2)
            
            s=pts.sum(axis =1)
            rect[0] = pts[np.argmin(s)]
            rect[2] = pts[np.argmax(s)]
            
            diff = np.diff(pts, axis=1)
            rect[1] = pts[np.argmin(diff)]
            rect[3] = pts[np.argmax(diff)]
            numero = numero +1

    return img,lista,agregar