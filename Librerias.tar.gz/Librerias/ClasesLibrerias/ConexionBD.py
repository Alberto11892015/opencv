import pymssql
import MySQLdb as mdb
import json


#!/usr/bin/env python
# -*- coding: utf-8 -*-
#workstation id=JSPruebas.mssql.somee.com;packet size=4096;user id=juan-sanchez-24_SQLLogin_1;pwd=jloodth941;
#data source=JSPruebas.mssql.somee.com;persist security info=False;initial catalog=JSPruebas
def connect():
    #host y puerto a db
    server = "JSPruebas.mssql.somee.com"
    #usuario
    user = "juan-sanchez-24_SQLLogin_1"
    #password
    password = "jloodth941"
    #nombre de la base de datos
    db = "JSPruebas"
    #ejecutar coneccion
    conn = pymssql.connect(server, user, password, db)
    return conn

def main():
    conn =connect()
    cursor = conn.cursor(as_dict=True)
    cursor.execute("Select * from Cuenta")
    row = cursor.fetchone()
    if row:
        print row
    conn.close()
def conexion():
    global coneccion
    global cursora

    coneccion = mdb.connect("albertoVGS.mysql.pythonanywhere-services.com","albertoVGS","bronsodia1","albertoVGS$vgsystem")
    cursora =coneccion.cursor()
    sql = 'create table prueba(id int,nombre varchar(45),descripcion varchar(45))'
    cursora.execute(sql)
    cursora.execute("insert into prueba(id,nombre,descripcion) values(1,'alberto','chico'")

    print "hora"
    cursora.execute('Select * from prueba')
    resultados = cursora.fetchall()
    for registro in resultados:
        id = registro[0]
        nombre = registro[1]
        descripcion = registro[2]

        print "id=%s,nombre=%s,descripcion=%d"%(id,nombre,descripcion)
    cursora.commit()
    cursora.close()
    coneccion.close()

if __name__ == '__main__':
    conexion()