'''
Created on 10/10/2016

@author: agaa8
'''
from ClasesLibrerias import Transformar as trans
from ClasesLibrerias import Multiusos as multi
from ClasesLibrerias import Encontrar as encontrar
from qrtools import QR
import os
import sys

import numpy as np
import argparse
import cv2
from numpy import dtype

def prueba(filas,columnas,img):

    img = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
    img2 = cv2.threshold(img,0,255,
       cv2.THRESH_BINARY |cv2.THRESH_OTSU)[1]

    img2 = cv2.resize(img, (545,643),interpolation = cv2.INTER_AREA)

    alto, ancho = img2.shape

    respuestasA = multi.cargargris("/home/alberto/Documentos/alberto110489-opencvutm-6fa95f115847/Librerias/imagenes/Fotos/betoA.jpg")
    respuestasB = multi.cargargris("/home/alberto/Documentos/alberto110489-opencvutm-6fa95f115847/Librerias/imagenes/Fotos/betoB.jpg")
    respuestasC = multi.cargargris("/home/alberto/Documentos/alberto110489-opencvutm-6fa95f115847/Librerias/imagenes/Fotos/betoC.jpg")
    respuestasD = multi.cargargris("/home/alberto/Documentos/alberto110489-opencvutm-6fa95f115847/Librerias/imagenes/Fotos/betoD.jpg")

    altopregunta = alto / filas
    anchopregunta = ancho / columnas
    listaAlto= []
    listaAncho =[]
    listares=[]
    for i in range(0,filas):
        listaAlto.append(altopregunta*i)

    for j in range(0,columnas):
        listaAncho.append(anchopregunta*j)
       
    respuesta = 0
    threshold = 0.6

    for c in range(0,columnas):

        for f in range(0,filas):
            detectado = False
            respuesta = respuesta +1 
            
            cv2.rectangle(img2,(listaAncho[c],listaAlto[f]),(listaAncho[c]+anchopregunta,listaAlto[f]+altopregunta),(0,25,0),2)
            cv2.imshow("img3",img2)
            cortada = img2[listaAlto[f]:listaAlto[f]+altopregunta+10,listaAncho[c]:listaAncho[c]+anchopregunta]

            detecionA = cv2.matchTemplate(cortada,respuestasA,cv2.TM_CCOEFF_NORMED)
                     
            detecA = np.where(detecionA >=threshold)
            
            for punto in zip(*detecA[::-1]):
                if detectado == False:
                    listares.append("A")
                    detectado = True        
                    break
            
            detecionB = cv2.matchTemplate(cortada,respuestasB,cv2.TM_CCOEFF_NORMED)
            detecB = np.where(detecionB >=threshold)
            for punto in zip(*detecB[::-1]):
                if detectado == False:
                    listares.append("B")
                    detectado = True        
                    break
            
            detecionC = cv2.matchTemplate(cortada,respuestasC,cv2.TM_CCOEFF_NORMED)
            detecC = np.where(detecionC >=threshold)
            for punto in zip(*detecC[::-1]):
                if detectado == False:
                    listares.append("C")
                    detectado = True
                    break
            
            detecionD = cv2.matchTemplate(cortada,respuestasD,cv2.TM_CCOEFF_NORMED)
            detecD = np.where(detecionD >=threshold)
            for punto in zip(*detecD[::-1]):
                if detectado == False:
                    listares.append("D")
                    detectado = True       
                    break
            if detectado == False:
                listares.append("----------------")
    respuestasBD = {0: "A", 1: "C", 2: "B", 3: "A", 4: "D", 5: "B",6:"C",7:"B",8:"A",9:"D",10:"A",11:"A",12:"C",13:"D",14:"B",15:"A",16:"A",17:"C",18:"B",19:"C",20:"C",21:"B",22:"D",23:"A",24:"A",25:"B",26:"B",27:"A",28:"A",29:"D"}
    for s in range(0, 30):
        if respuestasBD[s] == listares[s]:
            print str(s+1)+ " Correcto" + listares[s]
        else:
            print str(s+1)+" Incorrecto"+ listares[s]

    cv2.waitKey(0)

def LeerQR(imagenQR,nombre):
    ruta = os.getcwd()
    rutadirecta = ruta.strip('WbeService') +"imagenes/Qrs/" + nombre + ".png"
    print rutadirecta

    multi.guardar(imagenQR,nombre+".png")
    myCode = QR(filename=rutadirecta)
    if myCode.decode():
        print myCode.data
        print myCode.data_type
        print myCode.data_to_string()

